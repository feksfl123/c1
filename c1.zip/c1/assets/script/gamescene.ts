// Learn TypeScript:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
import startsceneob from "./startscene";  //引用pokerRes脚本里的PokerRes类

const {ccclass, property} = cc._decorator;

let PosLsit=[["2,3","2,4","2,5","2,6","2,7","2,8","2,9","3,3","3,4","3,5","3,6","3,7","3,8","3,9","4,3","4,4","4,5","4,6","4,7","4,8","4,9","5,3","5,4","5,5","5,6","5,7","5,8","5,9","2,3"],
                ["2,0","2,1","2,2","2,3","2,4","2,5","2,6","3,6","3,7","3,8","3,9","3,10","3,11","3,12","4,0","4,1","4,2","4,3","4,4","4,5","4,6","5,6","5,7","5,8","5,9","5,10","5,11","5,12","2,0"],
                ["0,0","0,1","0,2","0,3","0,4","0,5","0,6","1,6","1,7","1,8","1,9","1,10","1,11","1,12","4,0","4,1","4,2","4,3","4,4","4,5","4,6","5,6","5,7","5,8","5,9","5,10","5,11","5,12","0,0"],
                ["1,0","2,0","3,0","4,0","0,2","1,2","2,2","3,2","0,4","1,4","2,4","3,4","1,6","2,6","3,6","4,6","1,8","2,8","3,8","4,8","0,10","1,10","2,10","3,10","0,12","1,12","2,12","3,12","1,0"],
                ["6,0","5,0","4,0","3,0","6,2","5,2","4,2","3,2","6,4","5,4","4,4","3,4","6,6","5,6","4,6","3,6","6,8","5,8","4,8","3,8","6,10","5,10","4,10","3,10","6,12","5,12","4,12","3,12","6,0"],
                ["6,1","5,2","4,3","3,4","6,5","5,6","4,7","3,8","6,9","5,10","4,11","3,12","6,0","5,3","4,6","3,8","6,10","5,12","4,12","3,0","6,3","5,7","4,4","3,0","6,1","5,5","4,7","3,3","6,1"],
            ];

@ccclass
export default class NewClass extends cc.Component {

    //分
    Minute:number=0;
    //秒
    second:number=59;
    //毫秒
    millisecond:number=60;

    SecondControl:number=0;

    gametime:cc.Label;
    //图片数组
    @property([cc.SpriteFrame])
    Listsprite:Array<cc.SpriteFrame>=[];

    @property(cc.Prefab)
    item:cc.Prefab=null;
    @property(cc.Prefab)
    item1:cc.Prefab=null;
    @property(cc.Label)
    fraction:cc.Label=null;
    @property(cc.AudioClip)
    private adeffect: string = undefined;
    //上
    private AboveObList1:Array<cc.Node>=[];
    //下
    private underObList2:Array<cc.Node>=[];
    //左
    private lateObList3:Array<cc.Node>=[];
    //右
    private rightObList4:Array<cc.Node>=[];
    startOb:startsceneob=undefined;  //来自pokerRes脚本里的PokerRes类
    //游戏信息二维数组∂
    gameArrayDade:Array<Array<any>>=new Array<Array<any>>();
    //位置
    gamePosDade:Array<Array<Array<any>>>=[
        [[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2]],
        [[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2]],
        [[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2]],
        [[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2]],
        [[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2]],
        [[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2]],
        [[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2],[2]]
    ]

    ismobile:boolean=true;
    //当前选择的牌 
    Nowselectedob=null;

    //当前牌是否移动完成
    nowbrandMov:boolean=false;

    //移动方向指示
    direction:number=0;

    _curenlevenum:number=0;

    //总移动
    AllMoveTime:number=0;
    //现在移动 
    currentMoveTime:number=5;
    //音效按钮
    @property([cc.Node])
    gameSwitchMgt:Array<cc.Node>=[]

    onLoad () {
        this.gametime=this.node.getChildByName("scoringpanel").getChildByName("tiemr").getComponent(cc.Label);
    }

    start () {
        this.initMahjongData();
        this.GenerateMahjong();
        this.fraction.string=cc.sys.localStorage.getItem("levelnum");
        cc.sys.localStorage.setItem("Currentlevelnum",parseInt(cc.sys.localStorage.getItem("levelIdent"))+1*235);
        this._curenlevenum=(parseInt(cc.sys.localStorage.getItem("levelIdent"))+1)*235;
        this.node.getChildByName("scoringpanel").getChildByName("Level").getComponent(cc.Label).string=cc.sys.localStorage.getItem("Clicklevel")+"/8";
        this.MusiEffInit();
    }

    //初始化游戏数组
    initMahjongData()
    {
        for(var i = 0;i < 7;i++){
            this.gameArrayDade.push([]);
        }

        for(var i = 0;i < 7;i++){
            for(var j = 0;j < 13; j++)
            {
               for(var k = 0;k < 2; k++)
                {
                    this.gameArrayDade[i][j]=0;
                }
            }
        }

        for(var i = 0;i < 7;i++){
            for(var j = 0;j < 13; j++)
            {
               for(var k = 0;k < 2; k++)
                {
                    if(k===0)
                    {
                        this.gamePosDade[i][j][k]=66*j;
                    }
                    else
                    {
                        this.gamePosDade[i][j][k]=80*i;
                    }
                }
            }
        }

    }


    //生成麻将
    GenerateMahjong()
    {
        let npox1=parseInt(""+Math.random()*5);
        for(let i=1;i<29;i++)
        {
            this.scheduleOnce(()=>{
            let item=cc.instantiate(this.item);
            let num=parseInt(""+Math.random()*9);
            //向信息数组加状态
            this.SaveCardDate(item,num,i,npox1)
            this.scheduleOnce(()=>{
                item.runAction(cc.sequence(cc.scaleTo(0.25,1,1), cc.callFunc(() => null)));
            },0.1)
        },0.1)
        
        }
    }



    //保存牌的信息和位置
    SaveCardDate(_ob,_num,_nxi,nipx)
    {
        //let pox1=parseInt(""+Math.random()*7)
        //let pox2=parseInt(""+Math.random()*14)
        let ps=PosLsit[nipx][_nxi].split(",");

        if (this.gameArrayDade[ps[0]][ps[1]]<=1)
        {
            
            _ob.setPosition(this.gamePosDade[ps[0]][ps[1]][0],this.gamePosDade[ps[0]][ps[1]][1]);
            //_ob.setPosition(this.gamePosDade[pox1][pox2][0],this.gamePosDade[pox1][pox2][1])
            _ob.getComponent(cc.Sprite).spriteFrame=this.Listsprite[_num];
            _num+=1;
            this.gameArrayDade[ps[0]][ps[1]]=_nxi+","+_num;//parseInt(_nxi+","+_num)
            _ob.name=""+_nxi+","+_num;
            _ob.getChildByName("tag").getComponent(cc.Label).string=""+_nxi+","+_num;//_num
            _ob.getChildByName("num").getComponent(cc.Label).string=ps[0]+","+ps[1];
            this.node.getChildByName("nodeCore").addChild(_ob);
          
                _ob.on(cc.Node.EventType.TOUCH_START, function (event) {
                  if(this.ismobile===true&&this.nowbrandMov===false)
                  {
                    this.MovingJudgment(_ob);
                   // this.ismobile==false;
                  }

                }, this);
           
        }
        else
        {
            this.SaveCardDate(_ob,_num,_nxi,nipx);
        }
    }


    //移动
    MovingJudgment(_ob)
    {
        if(this.nowbrandMov===true)
        {
            //控制只能搞一次 
            return
        }
        var str=_ob.getChildByName("num").getComponent(cc.Label).string;
        let pos=str.split(",");

        //判断上下左右是否有牌
        this.MovePrejudge(pos[0],pos[1]);

        this.Mobilecontrol(_ob,pos[0],pos[1]);
    }

    //开始移动 
    Mobilecontrol(role,x,y)
    {
        role.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            //if (this.ismobile == false && this.Nowselectedob != null) {
                this.lectedPos(event);
           // }
        }, this);
        if(this.ismobile===false||this.nowbrandMov===true)
        {
            return
        }
        let _x=+x;
        let _y=+y;
        this.Nowselectedob=role;
  
        role.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
            this.node.getChildByName("shield").active=true;
            if(this.nowbrandMov===true)
            {
                //控制只能搞一次 
                return
            }
            this.nowbrandMov=true;
              //  cc.log("----------------------角色位置  ---"+"xxx:"+role.getPosition().x+"        yyy:"+role.getPosition().y)
              let pos=role.parent.convertToWorldSpaceAR(role.getPosition());
              let posx=event.touch.getLocationX();
              let posy=event.touch.getLocationY();

             // cc.log("----------------------世界坐  ---"+"xxx:"+pos.x+"        yyy:"+pos.y)
              //  cc.log("----------------------区域外离开 ---"+"xxx:"+event.touch.getLocationX()+"        yyy:"+event.touch.getLocationY())

                //上
                if (this.direction===1&&this.AboveObList1.length>=1) {
                    let pon =this.AboveObList1[this.AboveObList1.length-1].getPosition();

                    role.runAction(
                        cc.sequence(cc.moveTo(0.3,pon.x,pon.y),
                    cc.callFunc(() => null,
                    //判断移动的线上是否有相同的筒牌
                    )));
                    this.scheduleOnce(()=>{
                        this.nowbrandMov=true;
                       let str=this.AboveObList1[this.AboveObList1.length-1].getChildByName("num").getComponent(cc.Label).string;
                       let pos=str.split(",");
                       var str1=this.AboveObList1[this.AboveObList1.length-1].getChildByName("num1").getComponent(cc.Label).string;
                       let pos1=str1.split(",");
                       this.gameArrayDade[+pos1[0]][+pos1[1]]=0;
                       this.gameArrayDade[pos[0]][pos[1]]=role.name;
                       role.getChildByName("num").getComponent(cc.Label).string=pos[0]+","+pos[1];
                       this.CanYoueEliminate(role,parseInt(pos[0]),parseInt(pos[1]),1);
                    },0.3); 
                }
                //下
                else if(this.direction===2&&this.underObList2.length>=1) 
                {
                    let pon =this.underObList2[this.underObList2.length-1].getPosition();

                    role.runAction(
                        cc.sequence(cc.moveTo(0.3,pon.x,pon.y),
                    cc.callFunc(() => null

                    )));
                   this.scheduleOnce(()=>{
                        this.nowbrandMov=true;
                        var str=this.underObList2[this.underObList2.length-1].getChildByName("num").getComponent(cc.Label).string;
                        var str1=this.underObList2[this.underObList2.length-1].getChildByName("num1").getComponent(cc.Label).string;
                        let pos=str.split(",");
                        let pos1= str1.split(",");
                        this.gameArrayDade[+pos1[0]][+pos1[1]]=0;
                        this.gameArrayDade[pos[0]][pos[1]]=role.name;
                        role.getChildByName("num").getComponent(cc.Label).string=pos[0]+","+pos[1];
                        this.CanYoueEliminate(role,parseInt(pos[0]),parseInt(pos[1]),2);
                    },0.3); 
                  
                }
                //左
                else if(this.direction===3&&this.lateObList3.length>=1) {
                    let pon =this.lateObList3[this.lateObList3.length-1].getPosition();

                    role.runAction(
                        cc.sequence(cc.moveTo(0.3,pon.x,pon.y),
                    cc.callFunc(() => null

                    )));
                   this.scheduleOnce(()=>{
                        this.nowbrandMov=true;
                        var str=this.lateObList3[this.lateObList3.length-1].getChildByName("num").getComponent(cc.Label).string;
                        let pos=str.split(",");
                        var str1=this.lateObList3[this.lateObList3.length-1].getChildByName("num1").getComponent(cc.Label).string;
                        let pos1= str1.split(",");
                        this.gameArrayDade[+pos1[0]][+pos1[1]]=0;
                        this.gameArrayDade[pos[0]][pos[1]]=role.name;
                        role.getChildByName("num").getComponent(cc.Label).string=pos[0]+","+pos[1];
                        this.CanYoueEliminate(role,parseInt(pos[0]),parseInt(pos[1]),3);
                    },0.3); 
         
                }
                //右
                else if(this.direction===4&&this.rightObList4.length>=1) {
                    let pon =this.rightObList4[this.rightObList4.length-1].getPosition();

                    role.runAction(
                        cc.sequence(cc.moveTo(0.3,pon.x,pon.y,),
                            cc.callFunc(() => null
                    )));
                   this.scheduleOnce(()=>{
                        this.nowbrandMov=true;
                        var str=this.rightObList4[this.rightObList4.length-1].getChildByName("num").getComponent(cc.Label).string;
                        let pos=str.split(",");
                        var str1=this.rightObList4[this.rightObList4.length-1].getChildByName("num1").getComponent(cc.Label).string;
                        let pos1= str1.split(",");
                        this.gameArrayDade[+pos1[0]][+pos1[1]]=0;
                        this.gameArrayDade[pos[0]][pos[1]]=role.name;
                        role.getChildByName("num").getComponent(cc.Label).string=pos[0]+","+pos[1];
                        this.CanYoueEliminate(role,parseInt(pos[0]),parseInt(pos[1]),4);
                    },0.3);            
                }
                this.scheduleOnce(()=>{
                    this.nowbrandMov=false;
                     this.ismobile=true;
                 },0.3);   
                 this.scheduleOnce(()=>{
                    this.node.getChildByName("shield").active=false;
                 },0.35);     
        }, this);
    }

    lectedPos(event)
    {
        //实时计算鼠标位置
        let pos = this.Nowselectedob.parent.convertToWorldSpaceAR(this.Nowselectedob.getPosition());
        let posx = event.touch.getLocationX();
        let posy = event.touch.getLocationY();

        //上
        if (posy - 34 >= pos.y) {
            this.HideOtherPrompt(1);
            this.direction=1;
        }
        //下
        else if (pos.y - 34 >= posy) {
            this.HideOtherPrompt(2);
            this.direction=2;
        }
        //左
        else if (pos.x - 34 >= posx) {
            this.HideOtherPrompt(3);
            this.direction=3;
        }
        //右
        else if (posx - 34 >= pos.x) {
            this.HideOtherPrompt(4);
            this.direction=4;
        }
        else
        {
            this.direction=0;
        }
    }
    //判断是否能消除
    CanYoueEliminate(role,_x,_y,_num)
    {
        this.HideOtherPrompt(5);
           // if(_num==1)
           // {
                if(_x+1<7)
                {
                    if(this.gameArrayDade[_x+1][_y]!=null)
                    {
                        var name1=role.name;
                        var name2=this.gameArrayDade[_x+1][_y];
                        if(name2!=0)
                        {
                            let tg1= name1.split(",");
                            let tg2= name2.split(",");
        
                            if (tg1[1] === tg2[1]) {
                                role.destroy();
                                this.gameArrayDade[_x][_y]=0;
        
                                this.node.getChildByName("nodeCore").getChildByName(this.gameArrayDade[_x+1][_y]).destroy();
                                this.gameArrayDade[_x+1][_y]=0;
                                this.fraction.string=""+(parseInt(cc.sys.localStorage.getItem("levelnum"))+(10+parseInt(""+Math.random()*20)));
                                cc.sys.localStorage.setItem("levelnum",this.fraction.string);
                                
                                this.PlaySound();
                                let item1=cc.instantiate(this.item1);
                                let item2=cc.instantiate(this.item1);
                                
                                item1.setPosition(this.gamePosDade[_x+1][_y][0],this.gamePosDade[_x+1][_y][1]);
                                this.node.getChildByName("nodeCore").addChild(item1);
                                item2.setPosition(this.gamePosDade[_x][_y][0],this.gamePosDade[_x][_y][1]);
                                this.node.getChildByName("nodeCore").addChild(item2);
                                this.scheduleOnce(()=>
                                {
                                    item1.destroy();
                                    item2.destroy();
                                },0.4)

                            }
                            else {
            
                            }
                        }
         
                    }
                }
 
         
                if(_x-1>=0)
                {
                    if(this.gameArrayDade[_x-1][_y]!=null)
                    {
                        var name1=role.name;
                        var name2=this.gameArrayDade[_x-1][_y];
                        if(name2!=0)
                        {
                            let tg1= name1.split(",");
                            let tg2= name2.split(",");
        
                            if (tg1[1] === tg2[1]) {
        
                                role.destroy();
                                this.gameArrayDade[_x][_y]=0;
        
                                this.node.getChildByName("nodeCore").getChildByName(this.gameArrayDade[_x-1][_y]).destroy();
                                this.gameArrayDade[_x-1][_y]=0;
                                this.fraction.string=""+(parseInt(cc.sys.localStorage.getItem("levelnum"))+(10+parseInt(""+Math.random()*20)));
                                cc.sys.localStorage.setItem("levelnum",this.fraction.string);
                                this.PlaySound();
                                let item1=cc.instantiate(this.item1);
                                let item2=cc.instantiate(this.item1);
                                
                                item1.setPosition(this.gamePosDade[_x-1][_y][0],this.gamePosDade[_x-1][_y][1]);
                                this.node.getChildByName("nodeCore").addChild(item1);
                                item2.setPosition(this.gamePosDade[_x][_y][0],this.gamePosDade[_x][_y][1]);
                                this.node.getChildByName("nodeCore").addChild(item2);
                                this.scheduleOnce(()=>
                                {
                                    item1.destroy();
                                    item2.destroy();
                                },0.4)
                            }
                            else {
            
            
                            }
                        }
                    }
                }
 

                if(_y-1>=0)
                {
                    if(this.gameArrayDade[_x][_y-1]!=null)
                    {
                        var name1=role.name
                        var name2=this.gameArrayDade[_x][_y-1]
                        if(name2!=0)
                        {
                            let tg1= name1.split(",");
                            let tg2= name2.split(",");
        
                            if (tg1[1] === tg2[1]) {
        
                                role.destroy();
                                this.gameArrayDade[_x][_y]=0;
        
                                this.node.getChildByName("nodeCore").getChildByName(this.gameArrayDade[_x][_y-1]).destroy();
                                this.gameArrayDade[_x][_y-1]=0;
                                this.fraction.string=""+(parseInt(cc.sys.localStorage.getItem("levelnum"))+(10+parseInt(""+Math.random()*20)));
                                cc.sys.localStorage.setItem("levelnum",this.fraction.string);
                                this.PlaySound();
                                let item1=cc.instantiate(this.item1);
                                let item2=cc.instantiate(this.item1);
                                
                                item1.setPosition(this.gamePosDade[_x][_y-1][0],this.gamePosDade[_x][_y-1][1]);
                                this.node.getChildByName("nodeCore").addChild(item1);
                                item2.setPosition(this.gamePosDade[_x][_y][0],this.gamePosDade[_x][_y][1]);
                                this.node.getChildByName("nodeCore").addChild(item2);
                                this.scheduleOnce(()=>
                                {
                                    item1.destroy();
                                    item2.destroy();
                                },0.4)
                            }
                            else {
            
            
                            }
                       }
                    }
                }
 

                if(_y+1<14)
                {
                    if(this.gameArrayDade[_x][_y+1]!=null)
                    {
                        var name1=role.name;
                        var name2=this.gameArrayDade[_x][_y+1];
                        if(name2!=0)
                        {
                            let tg1= name1.split(",");
                            let tg2= name2.split(",");
        
                            if (tg1[1] === tg2[1]) {
        
                                role.destroy();
                                this.gameArrayDade[_x][_y]=0;
        
                                this.node.getChildByName("nodeCore").getChildByName( this.gameArrayDade[_x][_y+1]).destroy();
                                this.gameArrayDade[_x][_y+1]=0;
                                this.fraction.string=""+(parseInt(cc.sys.localStorage.getItem("levelnum"))+(10+parseInt(""+Math.random()*20)));
                                cc.sys.localStorage.setItem("levelnum",this.fraction.string);
                                this.PlaySound();
                                let item1=cc.instantiate(this.item1);
                                let item2=cc.instantiate(this.item1);
                                
                                item1.setPosition(this.gamePosDade[_x][_y+1][0],this.gamePosDade[_x][_y+1][1]);
                                this.node.getChildByName("nodeCore").addChild(item1);
                                item2.setPosition(this.gamePosDade[_x][_y][0],this.gamePosDade[_x][_y][1]);
                                this.node.getChildByName("nodeCore").addChild(item2);
                                this.scheduleOnce(()=>
                                {
                                    item1.destroy();
                                    item2.destroy();
                                },0.4)
                            }
                            else {
            
            
                            }
                        }
                    }
                }

            //判断是否胜利
            if(+cc.sys.localStorage.getItem("levelIdent")>=+cc.sys.localStorage.getItem("levelIdent")&&+this.fraction.string>=this._curenlevenum)
            {
                this.OpenVictory(1);
                
                cc.sys.localStorage.setItem("levelIdent",parseInt(cc.sys.localStorage.getItem("levelIdent"))+1);
                cc.sys.localStorage.setItem("Clicklevel",parseInt(cc.sys.localStorage.getItem("Clicklevel"))+1);
                this.millisecond=99

            }
    }

    //判断上下左右是否有牌
    MovePrejudge(x,y)
    {
        let _x=+x;
        let _y=+y;
        this.node.getChildByName("nodePos").removeAllChildren(true);
        this.AboveObList1=[];
        this.underObList2=[];
        this.lateObList3 =[];
        this.rightObList4=[];
  
        //上
        for(let i=_x+1;i<7;i++)
        {
            if(this.gameArrayDade[i][_y]<=0)
            {
                let item=cc.instantiate(this.item);
                item.setPosition(this.gamePosDade[i][_y][0],this.gamePosDade[i][_y][1]);
                item.getComponent(cc.Sprite).spriteFrame=this.Listsprite[10];
                item.getChildByName("num").getComponent(cc.Label).string=i+","+_y;
                item.getChildByName("num1").getComponent(cc.Label).string=_x+","+_y;
                item.setScale(0.5,0.5);
                this.node.getChildByName("nodePos").addChild(item);
                this.AboveObList1.push(item);
            }
            else
            {
                i=7;
            }
        }

        //下
        for(let i=_x-1;i>=0;i--)
        {
            if(this.gameArrayDade[i][_y]<=0)
            {
                let item=cc.instantiate(this.item);

                item.setPosition(this.gamePosDade[i][_y][0],this.gamePosDade[i][_y][1]);
                item.getComponent(cc.Sprite).spriteFrame=this.Listsprite[12];
                item.getChildByName("num").getComponent(cc.Label).string=i+","+_y;
                item.getChildByName("num1").getComponent(cc.Label).string=_x+","+_y;
                item.setScale(0.5,0.5);
                this.node.getChildByName("nodePos").addChild(item);
                this.underObList2.push(item);
            }
            else
            {
                i=0;
            }
        }

        //左
    
        for(let y1=_y-1;y1>=0;y1--)
        {
            if(this.gameArrayDade[_x][y1]<=0)
            {
                let item=cc.instantiate(this.item);

                item.setPosition(this.gamePosDade[_x][y1][0],this.gamePosDade[_x][y1][1]);
                item.getComponent(cc.Sprite).spriteFrame=this.Listsprite[14];
                item.getChildByName("num").getComponent(cc.Label).string=_x+","+y1;
                item.getChildByName("num1").getComponent(cc.Label).string=_x+","+_y;
                item.setScale(0.5,0.5);
                this.node.getChildByName("nodePos").addChild(item);
                this.lateObList3.push(item);
            }
            else
            {
                y1=0;
            }
        }

        //右
        for(let y2=_y+1;y2<13;y2++)
        {
            if(this.gameArrayDade[_x][y2]<=0)
            {
                let item=cc.instantiate(this.item);

                item.setPosition(this.gamePosDade[_x][y2][0],this.gamePosDade[_x][y2][1]);
                item.getComponent(cc.Sprite).spriteFrame=this.Listsprite[16];
                item.getChildByName("num").getComponent(cc.Label).string=_x+","+y2;
                item.getChildByName("num1").getComponent(cc.Label).string=_x+","+_y;
                item.setScale(0.5,0.5);
                this.node.getChildByName("nodePos").addChild(item);

                this.rightObList4.push(item);
            }
            else
            {
                y2=13;
            }
        }
        



    }


    HideOtherPrompt(_num)
    {
        let j;
        if(_num===1)
        {
            for(j in this.AboveObList1)
            {
                this.AboveObList1[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[9];
            }
            for(j in this.underObList2)
            {
                this.underObList2[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[12];
            }
    
            for(j in this.lateObList3)
            {
                this.lateObList3[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[14];
            }
    
            for(j in this.rightObList4)
            {
                this.rightObList4[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[16];
            }
        }
        else if(_num===2)
        {
            for(j in this.underObList2)
            {
                this.underObList2[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[11];
            }

            for(j in this.AboveObList1)
            {
                this.AboveObList1[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[10];
            }
    
            for(j in this.lateObList3)
            {
                this.lateObList3[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[14];
            }
    
            for(j in this.rightObList4)
            {
                this.rightObList4[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[16];
            }
        }
        else if(_num===3)
        {
            for(j in this.lateObList3)
            {
                this.lateObList3[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[13];
            }

            for(j in this.AboveObList1)
            {
                this.AboveObList1[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[10];
            }
    
            for(j in this.underObList2)
            {
                this.underObList2[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[12];
            }
    
            for(j in this.rightObList4)
            {
                this.rightObList4[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[16];
            }
        }
        else if(_num===4)
        {
            for(j in this.rightObList4)
            {
                this.rightObList4[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[15];
            }

            for(j in this.AboveObList1)
            {
                this.AboveObList1[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[10];
            }
    
            for(j in this.underObList2)
            {
                this.underObList2[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[12];
            }
    
            for(j in this.lateObList3)
            {
                this.lateObList3[j].getComponent(cc.Sprite).spriteFrame=this.Listsprite[14];
            }
        }
        else if(_num===5)
        {
            this.node.getChildByName("nodePos").removeAllChildren();
        }
    }




     update (dt) 
     {
        if (this.millisecond!=99)
        {
            this.millisecond-=1;
            if (this.millisecond<=0&&this.second>=1)
            {
                this.second-=1;
                this.millisecond=59;
                if (this.second<=0&&this.Minute>=1)
                {
                    this.second=59;
                    this.Minute-=1;
                }
                if (this.second>=10)
                {
                    this.gametime.string="0"+this.Minute+":"+""+this.second;
                }
                else
                {
                    this.gametime.string="0"+this.Minute+":"+"0"+this.second;
                }
            }
            else if(this.Minute<=0&&this.second<=0)
            {
                //判断是否结束
                this.OpenVictory(2);
            }
        }

     }



     //下一关
     victory()
     {
         cc.director.loadScene("game");
         this.node.getChildByName("victoryPanel").active=false;
     }

     //打开下一关
     OpenVictory(_num)
     {
        this.node.getChildByName("victoryPanel").active=true;
         if(_num===1)
         {
            this.node.getChildByName("victoryPanel").getChildByName("Node1").active=true;
            this.node.getChildByName("victoryPanel").getChildByName("Node2").active=false;
            
            this.node.getChildByName("victoryPanel").getChildByName("Node1").getChildByName("num").getComponent(cc.Label).string=""+this._curenlevenum;
         }
         else if(_num===2)
         {
            this.node.getChildByName("victoryPanel").getChildByName("Node1").active=false;
            this.node.getChildByName("victoryPanel").getChildByName("Node2").active=true;

         }
     }


     //结束
     ENDGame()
     {
        cc.director.loadScene("start");
     }

     //打开游戏管理界面
     OpenGameDirector()
     {
        this.musiEffPanel()
        this.node.getChildByName("GameDirorPanel").active=true;

     }

     GameDirectorBtn(ob,_num)
     {
        cc.director.resume();
        if (_num == 0) 
        {
            this.OpenGameDirector();
            cc.director.pause();
        }
        else if(_num==1)
        {
            cc.director.resume();
            this.node.getChildByName("GameDirorPanel").active=false;
        }
        else if(_num==2)
        {
            cc.director.loadScene("leven");
        }
        else if(_num==3)
        {

        }
        else if(_num==4)
        {

        }
        else if(_num==5)
        {
            this.gameSwitchMgt[1].active=true;
            this.gameSwitchMgt[2].active=false;
          //  this.gameSwitchMgt[5].active=false;
           // this.gameSwitchMgt[6].active=true;

            cc.sys.localStorage.setItem("music",1);
            cc.audioEngine.pauseAll();
        }
        else if(_num==6)
        {
            this.gameSwitchMgt[1].active=false;
            this.gameSwitchMgt[2].active=true;
            //this.gameSwitchMgt[5].active=true;
           // this.gameSwitchMgt[6].active=false;

            cc.sys.localStorage.setItem("music",0);
            cc.audioEngine.resumeAll();
        }
        else if(_num==7)
        {
          //  this.gameSwitchMgt[3].active=false;
          //  this.gameSwitchMgt[4].active=true;
           // this.gameSwitchMgt[7].active=false;
          //  this.gameSwitchMgt[8].active=true;

            cc.sys.localStorage.setItem("Soundeffect",1);
        }
        else if(_num==8)
        {
          //  this.gameSwitchMgt[3].active=true;
         //   this.gameSwitchMgt[4].active=false;
          //  this.gameSwitchMgt[7].active=true;
          //  this.gameSwitchMgt[8].active=false;

            cc.sys.localStorage.setItem("Soundeffect",0);
        }
     }

     MusiEffInit()
     {
        if(cc.sys.localStorage.getItem("music")==0)
        {
            this.gameSwitchMgt[1].active=false;
            this.gameSwitchMgt[2].active=true;
        }
        else
        {
            this.gameSwitchMgt[1].active=true;
            this.gameSwitchMgt[2].active=false;
        }

        if(cc.sys.localStorage.getItem("Soundeffect")==1)
        {
           // this.gameSwitchMgt[3].active=false;
         //   this.gameSwitchMgt[4].active=true;
        }
        else
        {
          //  this.gameSwitchMgt[3].active=true;
          //  this.gameSwitchMgt[4].active=false;

        }
     }

     musiEffPanel()
     {
        // if(cc.sys.localStorage.getItem("music")!=0)
        // {
        //     this.gameSwitchMgt[5].active=false;
        //     this.gameSwitchMgt[6].active=true;
        // }
        // else
        // {
        //     this.gameSwitchMgt[5].active=true;
        //     this.gameSwitchMgt[6].active=false;
        // }

        // if(cc.sys.localStorage.getItem("Soundeffect")==1)
        // {
        //     this.gameSwitchMgt[7].active=false;
        //     this.gameSwitchMgt[8].active=true;
        // }
        // else
        // {
        //     this.gameSwitchMgt[7].active=true;
        //     this.gameSwitchMgt[8].active=false;
        // }
     }

     PlaySound()
     {
         if(cc.sys.localStorage.getItem("Soundeffect")==="0")
         {
            cc.audioEngine.play(this.adeffect,false,1.0);
         }
       
     }

  
}
