import { dev, ckUp, newVer, enc_s, dec_s, appleId } from "./begin/tools"
const localStorage: Storage = cc.sys.localStorage
const {ccclass, property} = cc._decorator;
let music=0
let musicob=undefined
@ccclass
export default class startscene  extends cc.Component {
     @property(cc.Node)
     private Btn2:cc.Node=undefined;
     @property(cc.Node)
     private Btn3:cc.Node=undefined;
     @property(cc.Node)
     private Btn4:cc.Node=undefined;
     @property(cc.AudioClip)
     private adBg: string = undefined;

     onLoad () {
         if(music==0)
         {
              cc.audioEngine.play(this.adBg,true, 1);
              music=1;
         }
     }


     async start () {
        
        if(cc.sys.localStorage.getItem("music")===null)
        {
            cc.sys.localStorage.setItem("music",0);
            cc.log("初始化数据");
        }
        if(cc.sys.localStorage.getItem("Soundeffect")===null)
        {
            cc.sys.localStorage.setItem("Soundeffect",0);
            cc.log("初始化数据");
        }
      
        var dd=cc.sys.localStorage.getItem("music");
        this.scheduleOnce(function() {
            if(cc.sys.localStorage.getItem("music")==="0")
            {
                cc.audioEngine.resumeAll();
            }
            else
            {
               cc.audioEngine.pauseAll();
            }
        }, 0.55);
        this.Btn2.runAction(cc.sequence(cc.moveTo(0.25,-6,-218), cc.callFunc(() => null)));
   
    }

    Callback()
    {
        cc.director.loadScene("leven");
    }
    Callback1(ob,_num)
    {
        if(_num=="1")
        {
            this.Btn4.active=true;
            if(cc.sys.isNative)
            {
               jsb.reflection.callStaticMethod("MocdMbroin", "showVideo");
            }
            
        }
        else
        {
            this.Btn4.active=false;
        }
    }


}








