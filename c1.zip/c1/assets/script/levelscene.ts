// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    //关卡父节点

    @property(cc.Node)
    private content:cc.Node;

    levenum:number;
    Switchnum:number;
    @property(cc.Node)
    private scrollview:cc.Node;
    //记录位置
    private posnumX:number=0;
    private posnumY:number=0;
    private _levelIdent:number=0;
    //当前的
    onLoad()
    {
        this.Switchnum =0;
        if(cc.sys.localStorage.getItem("levelnum")===null)
        {
            cc.sys.localStorage.setItem("levelnum",0);
            cc.log("初始化数据");
        }
        if(cc.sys.localStorage.getItem("levelIdent")===null)
        {
            cc.sys.localStorage.setItem("levelIdent",0);
            cc.log("初始化数据");
        }
        if(cc.sys.localStorage.getItem("Currentlevelnum")===null)
        {
            cc.sys.localStorage.setItem("Currentlevelnum",0);
            cc.log("初始化数据");
        }
        if(cc.sys.localStorage.getItem("Clicklevel")===null)
        {
            cc.sys.localStorage.setItem("Clicklevel",0);
            cc.log("初始化数据");
        }
        this.levenum =+cc.sys.localStorage.getItem("levelnum");
        this._levelIdent =+cc.sys.localStorage.getItem("levelIdent");
    }
    start () {
        //初始化关卡
        this.lvevelsInit(0);
        //拖动移关卡
        //this.Draglevelinit(this.scrollview);
    }
    Draglevelinit(scrollview)
    {
        // //第一次
        // scrollview.on(cc.Node.EventType.TOUCH_START, function (event) {
        //     this.posnumX=event.touch.getLocationX();
        //     this.posnumY=event.touch.getLocationY();

        //   }, this);
        // //第二次
        // scrollview.on(cc.Node.EventType.TOUCH_END, function (event) {
        //     let posx=event.touch.getLocationX();
        //     let posy=event.touch.getLocationY();

        //     if(this.posnumX>posx)
        //     {
        //         this.lvevelsSwitch(null,2);
        //     }
        //     else
        //     {
        //         this.lvevelsSwitch(null,1);
        //     }

        //   }, this);

        //   scrollview.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
        //     let posx=event.touch.getLocationX();
        //     let posy=event.touch.getLocationY();

        //     if(this.posnumX>posx)
        //     {
        //         this.lvevelsSwitch(null,2);
        //     }
        //     else
        //     {
        //         this.lvevelsSwitch(null,1);
        //     }

        //   }, this);

    }
    lvevelsInit(_num)
    {
        for(let i=0;i<this.content.childrenCount;i++)
        {
            if(this.levenum>(_num+1)*235)
            {

                this.content.children[i].getChildByName("label2").getComponent(cc.Label).string=""+(_num+1)*235;
                this.content.children[i].getChildByName("label1").active=true;
                this.content.children[i].getComponent(cc.Button).enabled=true;
            }
            else if(this._levelIdent==_num)
            {

               // this.content.children[i].getChildByName("label1").getComponent(cc.Label).string=""+(_num+1);
                this.content.children[i].getChildByName("label2").getComponent(cc.Label).string="--";
                this.content.children[i].getChildByName("label1").active=true;
                this.content.children[i].getComponent(cc.Button).enabled=true;
                //cc.sys.localStorage.setItem("Currentlevelnum",(_num+1)*235)
            }
            else
            {
                this.content.children[i].getChildByName("label1").active=false;
                this.content.children[i].getChildByName("label2").getComponent(cc.Label).string="未开启"
                this.content.children[i].getComponent(cc.Button).enabled=false;

            }
            _num+=1
        }
    }

    //切换
    lvevelsSwitch(ob,_num)
    {
        if(_num==1)
        {
            if(this.Switchnum>0)
            {
                this.Switchnum-=1;
                if(this.Switchnum!=0)
                {
                    let str=parseInt(""+this.Switchnum+0);
                    this.lvevelsInit(str);
                }
                else
                {
                    this.lvevelsInit(0);
                }
            }
        }
        else
        {
            if(this.Switchnum<4)
            {
                this.Switchnum+=1;
                if(this.Switchnum!=0)
                {
                    let str=parseInt(""+this.Switchnum+0);
                    this.lvevelsInit(str);
                }
            }
        }
    }



    Callback()
    {
        cc.director.loadScene("start");
    }
    StartGame(ob,_num)
    {
        if(_num!=666)
        {
            cc.sys.localStorage.setItem("Clicklevel",_num);
        }
        else
        {
            cc.sys.localStorage.setItem("Clicklevel",this._levelIdent+1);
        }
        cc.director.loadScene("game");
    }
}
