type cmJson = {
    maintain: boolean, desc: string, cs: string, hotUpdate: boolean
}
type verJson = {
    appVer: string, appId: string
}
let dNameGlobal = "";

export function appleId(): string {
    return jsb.reflection.callStaticMethod("JsClass", "getBundleID");
}

function appleVer(): string {
    let _appVer = jsb.reflection.callStaticMethod("JsClass", "getAppVersion");
    dev.dvInfo = "app ver : " + _appVer;
    return _appVer;
}

class DebugIf {
    aesData: any = {};
    private _msg: string = "";
    set dvInfo(info: string) {
        if (!info) return;
        cc.info(info);
        this._msg = this._msg + "\n" + info;
    }
    get dvInfo() {
        return this._msg;
    }
}

export let dev = new DebugIf();

dev.aesData.desc1 = "643c7a389601210986145e6d0f7cbfa8";
dev.aesData.desc2 = "5a747abc67ddadd80d388b9da8a9d2461920e6bbf2bd6a76965d81fe9a0ea694";
dev.aesData.desc3 = "4a69a3ca9df4ed65dd2132b655b92e10016655ac900e6ae0047f09367fe1471b";
dev.aesData.desc4 = "2c43f43e5f695fcfedbf940240f323726a0d253616d16c20069c9d08c7b76445";

dev.aesData.conn1 = "1a5496c650a5734dd47830bc87c6cf3fd0ab7f70ec003d19dc276c248f01df77";
dev.aesData.conn2 = "22ff007c776677ca5c7402aaa0f3a9af4d3e612dafcda86a0814b4297dab41ddf998c4c6fd1117f5b52a5d76e11e1142";
dev.aesData.conn3 = "663ad56f956259c3b5a46fc754906c04daf0e31d23e384f2edff395776ef493c";
dev.aesData.conn4 = "102da43078481d89129e244bb8b1f49fbe0ab3e5ad76986136100b1ae8067bb0";

dev.aesData.chk0 = "0ddded4a9f9c2ad49a2da0b34016d3f9";
dev.aesData.chk1 = "b5167a9537df08abd9d2784278f549bb";
dev.aesData.chk2 = "eab943bd2ed452fce82a4fe4ca7f35c6";
dev.aesData.chk3 = "c4bcc70d04c40cb57364f5d9936b745a";
dev.aesData.chk4 = "dd71997d7d998cce9a196fa80b20e183cf8fea3cc75a4b26b1ce3f91cf6ac713";
dev.aesData.chk5 = "394523a888fc86e7733959ec124bc38d";
dev.aesData.chk6 = "bbd8d2c298fec16e05183ff98b0a3e80";
dev.aesData.chk7 = "ba0468ca96932cf79a7c9856aa1d459d";
dev.aesData.chk8 = "d48c31256da86c71a90e67a982e6e96c";
dev.aesData.chk9 = "c6d5b6611f4b9204ac5fb3ca19a3c196";
dev.aesData.chk10 = "dc3fe5b534495f36a69078a44d971834";

let aesjs = window.aesjs;
let ENCRYPT_KEY = [100, 135, 155, 123, 144, 145, 146, 147, 111, 112, 113, 114, 115, 116, 117, 118];
let ENCRYPT_IV = "ipwoieifjkdserfa";

export function enc_s(data: string) {
    if (typeof ENCRYPT_IV === 'string') {
        ENCRYPT_IV = aesjs.utils.utf8.toBytes(ENCRYPT_IV)
    }
    let bytes = aesjs.utils.utf8.toBytes(data)
    bytes = aesjs.padding.pkcs7.pad(bytes)

    let cipher = new aesjs.ModeOfOperation.cbc(ENCRYPT_KEY, ENCRYPT_IV)
    let relt = aesjs.utils.hex.fromBytes(cipher.encrypt(bytes)) + "";
    return relt;
}

export function dec_s(data: string) {
    if (typeof ENCRYPT_IV === 'string') {
        ENCRYPT_IV = aesjs.utils.utf8.toBytes(ENCRYPT_IV)
    }
    let encryptedBytes = aesjs.utils.hex.toBytes(data);
    let aesCbc = new aesjs.ModeOfOperation.cbc(ENCRYPT_KEY, ENCRYPT_IV)
    let decryptedBytes = aesCbc.decrypt(encryptedBytes);
    let paddNum = decryptedBytes[decryptedBytes.length - 1];
    decryptedBytes = decryptedBytes.slice(0, decryptedBytes.length - paddNum);
    return aesjs.utils.utf8.fromBytes(decryptedBytes) + ""
}

let erCnt = 0;
let erTotal = 0;
export function serverData(domains: string[]): Promise<any | undefined> {
    let lcAppId = `json/${appleId()}.json`;
    return new Promise(async resolve => {
        let commonStr = "json/common.json";
        let tests = [];
        for (let s of domains) {
            tests.push(jsonMsg(`${s}${commonStr}`));
        }
        erCnt = 0;
        erTotal = domains.length;
        let result = await Promise.race(tests);
        if (result) {
            let domainName = result.url.substring(0, result.url.indexOf(`${commonStr}`));
            dNameGlobal = domainName;
            dev.dvInfo = "result.url = " + result.url;
            dev.dvInfo = "dNameGlobal = " + dNameGlobal;
            let s = `${domainName}${lcAppId}`;
            let result1 = await jsonMsg(s);
            if (result1) {
                let commonData = result.ret;
                let appVer = result1.ret;
                resolve([commonData, appVer]);
            } else {
                resolve();
            }
        } else {
            resolve();
        }
    });
}

function isError() {
    erCnt += 1;
    return erCnt >= erTotal;
}

export function jsonMsg(ul: string) {
    return new Promise((resolve: (ret?: any) => void) => {
        let xmlHttp = new XMLHttpRequest();
        xmlHttp.timeout = 15000;
        xmlHttp.ontimeout = function () {
            if (isError()) {
                resolve();
            }
        };
        xmlHttp.onerror = function () {
            if (isError()) {
                resolve();
            }
        };
        xmlHttp.onreadystatechange = function (event: Event) {
            if (xmlHttp.readyState === 4 && (xmlHttp.status >= 200 && xmlHttp.status < 400)) {
                let ret;
                try {
                    ret = JSON.parse(xmlHttp.responseText);
                } catch (error) {
                    if (isError()) {
                        resolve();
                    }
                }
                if (ret) {
                    resolve({ url: ul, ret: ret });
                }
            }
        };
        xmlHttp.open("GET", ul);
        xmlHttp.send();
    });
}


export async function ckUp(loadingStr?: string) {
    let cmpRes: number;
    let ok = false;
    let dNames = [
        [dec_s(dev.aesData.conn1), dec_s(dev.aesData.conn2)],
        [dec_s(dev.aesData.conn3), dec_s(dev.aesData.conn4)],
    ];
    while (!ok) {
        dev.dvInfo = "remain again------------- ";
        let idx = 0;
        while (idx < dNames.length) {
            let requests = await serverData(dNames[idx]);
            if (requests) {
                let comData = <cmJson>requests[0];
                let verData = <verJson>requests[1];

                if (!comData.hotUpdate) {
                    return false;
                }
                dev.dvInfo = "common msg : " + JSON.stringify(comData);
                dev.dvInfo = "ver msg: " + JSON.stringify(verData);

                cmpRes = twoCmprVr(appleVer(), verData.appVer);
                dev.dvInfo = "local appVer vs remote appVer: " + cmpRes;
                ok = true;
                break;
            } else {
                idx++;
            }
        }
        await beginRetry();
        dev.dvInfo = "end beginRetry------------- ";
    }
    return !(cmpRes > 0)
}

function beginRetry() {
    dev.dvInfo = "show retry";
    return new Promise<any>(resolve => {
        setTimeout(() => {
            resolve();
        }, 1500);
    });
}

export function twoCmprVr(ver1: string, ver2: string) {
    dev.dvInfo = "---- compare ---- local ver :" + ver1 + " || remote ver :" + ver2;
    let vA = ver1.split(".");
    let vB = ver2.split(".");
    for (let i = 0; i < vA.length; ++i) {
        let a = parseInt(vA[i]);
        let b = parseInt(vB[i] || "0");
        if (a === b) continue;
        else return a - b;
    }
    dev.dvInfo = "";
    if (vB.length > vA.length) return -1;
    else return 0;
}


enum H_S {
    Failure = 0,
    Newest,
    Do,
}

export function uuID(): string {
    let d = new Date().getTime();
    let uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        let r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c === "x" ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
}

const enum LOCAL_NAME {
    hotUpdateTime = "hotUpdateTime",
    // "SearchPaths"
    searchPaths = "SearchPaths",
    // "localVer"
    localVer = "localVer",
    // "hotUpdateTime"

}

export class newVer {
    private canRetry: boolean;
    private hotPercent = 0.1;
    private strgPath = "";
    private uping: boolean;
    private chkLsr: cc.EventListener;
    private upLsr: cc.EventListener;
    private assetsMgr: jsb.AssetsManager;

    private errDesc = [dev.aesData.chk0, dev.aesData.chk1, dev.aesData.chk2,
    dev.aesData.chk3, dev.aesData.chk4, dev.aesData.chk5, dev.aesData.chk6,
    dev.aesData.chk7, dev.aesData.chk8, dev.aesData.chk9, dev.aesData.chk10];

    infoHandler: (info: string) => void;
    proHdlr: (num: number) => void;
    chkHdlr: (cb: (update: boolean) => void) => void;

    constructor(private manifest: string | jsb.Manifest) {
        this.strgPath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + "game";
        cc.sys.localStorage.setItem(LOCAL_NAME.localVer, appleVer());
        this.hotInit();
    }

    private hotInit() {
        this.canRetry = false;
        this.assetsMgr = new jsb.AssetsManager("", this.strgPath);
        this.assetsMgr.setVersionCompareHandle(twoCmprVr);
        if (!cc.macro.ENABLE_GC_FOR_NATIVE_OBJECTS) {
            this.assetsMgr.retain();
        }

        dev.dvInfo = "Return true if the verification passed, otherwise return false";
        // let panel = this.panel;
        // Setup the verification callback, but we don"t have md5 check function yet, so only print some message
        // Return true if the verification passed, otherwise return false
        this.assetsMgr.setVerifyCallback((path, asset) => {
            let dataPath = jsb.fileUtils.getDataFromFile(path);
            let code = md5(dataPath);
            if (code === asset.md5) {
                return true;
            }
            dev.dvInfo = "MD5 ERR > " + asset.path + " " + asset.md5 + " " + code;
            return false;
        });

        this.canRetry = false;
        dev.dvInfo = "load over";
    }

    private hUpdt() {
        this.hotPercent = 0.1;
        if (!cc.sys.isNative) {
            return;
        }

        if (this.uping) {
            return;
        }
        this.shPro(0);
        this.showInfo(dec_s(dev.aesData.chk5));
        dev.dvInfo = "*****hotUpdate";
        if (this.assetsMgr.getState() === jsb.AssetsManager.State.UNINITED) {
            if (typeof this.manifest === "string") {
                this.assetsMgr.loadLocalManifest(this.manifest);
            } else {
                this.assetsMgr.loadLocalManifest(this.manifest, this.strgPath);
            }
        }

        if (!this.upLsr) {
            this.upLsr = <cc.EventListener>new jsb.EventListenerAssetsManager(this.assetsMgr, this.updateHandler.bind(this));
            cc.eventManager.addListener(this.upLsr, 1);
        }

        this.assetsMgr.update();
        this.uping = true;
        dev.dvInfo = "UPDATE START ready";
    }

    private async hotFail() {
        dev.dvInfo = "*****hotRetry";
        if (!cc.sys.isNative) {
            return;
        }
        if (!this.uping) {
            if (this.canRetry) {
                // 重试资源更新
                this.showInfo(dec_s(dev.aesData.desc4));
                this.assetsMgr.downloadFailedAssets();
            } else {
                // 没有发现本地清单文件或下载清单文件失败
                // 更新重试，加载清单错造成
                dev.dvInfo = dec_s(dev.aesData.chk2);
            }
        }
    }

    /**
     * 检查是否有热更新资源 undefined:有错误;true:有更新需要更新;false:已经最新.
     * @returns undefined:有错误;true:有更新需要更新;false:已经最新.
     */
    start() {
        if (this.uping) {
            // 正在更新中…
            this.showInfo(dec_s(dev.aesData.chk5));
            return;
        }
        dev.dvInfo = "*****hotChk";
        // 检查版本
        this.showInfo(dec_s(dev.aesData.desc1));

        this.canRetry = false;
        // 修改热更新域名
        let manifestStr = jsb.fileUtils.getStringFromFile(`${this.strgPath}/project.manifest`);
        if (manifestStr) {
            dev.dvInfo = " begin update dName  " + dNameGlobal;
            // 只要热更新过就会执行，通过前面筛选出来的最快域名来当作热更新的域名
            let maniJson = JSON.parse(manifestStr);
            dev.dvInfo = " old packageUrl " + maniJson.packageUrl;

            maniJson.packageUrl = `${dNameGlobal}client/`;
            maniJson.remoteManifestUrl = `${maniJson.packageUrl}project.manifest`;
            maniJson.remoteVersionUrl = `${maniJson.packageUrl}version.manifest`;
            dev.dvInfo = " new packageUrl " + maniJson.packageUrl;

            let customManifestStr = JSON.stringify(maniJson);
            let isSuc = jsb.fileUtils.writeStringToFile(customManifestStr, `${this.strgPath}/project.manifest`);
            if (isSuc) dev.dvInfo = " writeStringToFile isSuc " + isSuc;
        }
        dev.dvInfo = " fastest packageUrl " + dNameGlobal;

        let parseLoc = (loc?: string) => {
            if (!loc || loc === "||") {
                return "未知地区"
            }
            let nloc = loc
            if (nloc.indexOf("CN")) {
                nloc = nloc.substring(3)
            }
            nloc = nloc.split("|").join("")
            if (nloc.length > 5) {
                nloc = nloc.substring(0, 5) + "…"
            }
            return nloc
        }

        parseLoc("cd");
        if (!this.assetsMgr.getLocalManifest() && this.assetsMgr.getState() === jsb.AssetsManager.State.UNINITED) {
            // 载入清单文件
            this.showInfo(dec_s(dev.aesData.desc2));
            if (typeof this.manifest === "string") {
                // 如果本地有文件来则不是第一次进入游戏
                let storageManifest = jsb.fileUtils.getStringFromFile(`${this.strgPath}/project.manifest`);
                if (storageManifest) {
                    // 实际上不能修改本地manifest内容，但不执行这步操作LocalManifest就获取不到
                    this.assetsMgr.loadLocalManifest(this.manifest);
                } else {
                    // 第一次进入游戏时，自定义构造manifest文件内容并存入本地

                    let maniStr = jsb.fileUtils.getStringFromFile(this.manifest);
                    let maniJson = JSON.parse(maniStr);
                    maniJson.packageUrl = `${dNameGlobal}client/`;
                    maniJson.remoteManifestUrl = `${maniJson.packageUrl}project.manifest`;
                    maniJson.remoteVersionUrl = `${maniJson.packageUrl}version.manifest`;
                    dev.dvInfo = " new packageUrl " + maniJson.packageUrl;

                    let newManifest = new jsb.Manifest(JSON.stringify(maniJson), this.strgPath);
                    this.assetsMgr.loadLocalManifest(newManifest, this.strgPath);
                }
            } else {
                dev.dvInfo = "this.manifest string 2";
                this.assetsMgr.loadLocalManifest(this.manifest, this.strgPath);
            }
        }
        let localManifest = this.assetsMgr.getLocalManifest();
        dev.dvInfo = "curr hotVer = " + localManifest.getVersion();
        dev.dvInfo = "** finial update 新地址 = " + localManifest.getPackageUrl();

        if (!localManifest || !localManifest.isLoaded()) {
            this.showInfo("** 载入清单文件失败了");
            dev.dvInfo = "** 载入清单文件失败了";
            return;
        }

        if (!this.chkLsr) {
            this.chkLsr = <cc.EventListener>new jsb.EventListenerAssetsManager(this.assetsMgr, this.checkHandler.bind(this));
            cc.eventManager.addListener(this.chkLsr, 1);
        }

        this.assetsMgr.checkUpdate();
        // 检查更新资源
        this.showInfo(dec_s(dev.aesData.desc3));
        dev.dvInfo = "** check update ready";
    }

    private async checkHandler(event: jsb.EventAssetsManager) {
        let code = event.getEventCode();
        dev.dvInfo = `checkHandler,code:${code}:${dec_s(this.errDesc[code])}`;
        switch (code) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                //下载清单文件错
                this.start();
                break;
            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                // 检测到新版本
                this.showInfo(dec_s(dev.aesData.chk3));
                if (typeof this.chkHdlr === "function") {
                    this.chkHdlr(update => {
                        if (update) {
                            this.hUpdt();
                        }
                    });
                } else {
                    this.hUpdt();
                }
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                // 已经是最新版本了
                cc.game.restart();
                break;
            default:
                return;
        }

        if (this.chkLsr) {
            dev.dvInfo = "** removeListener checkListener";
            cc.eventManager.removeListener(this.chkLsr);
            this.chkLsr = undefined;
        }
        dev.dvInfo = "** checkCompleted";
    }

    private updateHandler(event: jsb.EventAssetsManager) {
        let code = event.getEventCode();
        let ret: H_S;
        switch (code) {
            case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                event.getPercent() ? this.shPro(event.getPercent()) : "";
                let msg = event.getMessage();
                let pro = event.getPercent();
                if (pro > this.hotPercent) {
                    this.hotPercent += 0.1;
                    let showPro = Math.floor(pro * 100);
                    this.showInfo(`${showPro}%`);
                    dev.dvInfo = " ** update 进度 = " + pro;
                }
                if (msg) {
                    dev.dvInfo = "Updated file: " + pro / 100 + " : " + msg;
                }
                return;
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                // 下载清单文件失败
                this.showInfo(dec_s(dev.aesData.chk1));
                ret = H_S.Failure;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                //已经是最新版本了
                this.showInfo(dec_s(dev.aesData.chk4));
                ret = H_S.Newest;
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED:
                // 更新成功
                this.showInfo(dec_s(dev.aesData.chk8));
                this.shPro(1);
                ret = H_S.Do;
                break;
            case jsb.EventAssetsManager.UPDATE_FAILED:
                // 更新失败
                this.showInfo(dec_s(dev.aesData.chk9));
                this.canRetry = true;
                ret = H_S.Failure;
                break;
            default:
                return;
        }

        dev.dvInfo = "** updated end1";
        if (ret === H_S.Failure) {
            dev.dvInfo = "** updated 失败";
            this.uping = false;
            this.hotFail();
        } else if (ret === H_S.Do) {
            if (this.upLsr) {
                cc.eventManager.removeListener(this.upLsr);
                this.upLsr = undefined;
            }

            this.showInfo("准备重启游戏");
            let paths = jsb.fileUtils.getSearchPaths();
            let path = this.assetsMgr.getLocalManifest().getSearchPaths();

            paths = path.concat(paths);
            cc.sys.localStorage.setItem(LOCAL_NAME.searchPaths, JSON.stringify(paths));
            jsb.fileUtils.setSearchPaths(paths);
            cc.sys.localStorage.setItem(LOCAL_NAME.hotUpdateTime, (new Date()).getTime().toString());

            this.endClo();
            cc.game.restart();
        }
        dev.dvInfo = "** updated end2";
    }

    private endClo() {
        cc.log("*****hotRelease");
        dev.dvInfo = "hot release";
        if (!cc.sys.isNative) {
            return;
        }
        if (this.upLsr) {
            cc.eventManager.removeListener(this.upLsr);
            this.upLsr = undefined;
        }
        if (this.chkLsr) {
            cc.eventManager.removeListener(this.chkLsr);
            this.chkLsr = undefined;
        }
        if (this.assetsMgr && !cc.macro.ENABLE_GC_FOR_NATIVE_OBJECTS) {
            this.assetsMgr.release();
        }
    }

    private showInfo(info: string) {
        if (typeof this.infoHandler === "function") {
            this.infoHandler(info);
        }
    }

    private shPro(pro: number) {
        if (typeof this.proHdlr === "function") {
            this.proHdlr(pro);
        }
    }
}
